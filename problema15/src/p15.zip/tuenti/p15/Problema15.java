package tuenti.p15;

public class Problema15 {
	public static void main(String[] args) {
		System.out.println("389");
	}
}

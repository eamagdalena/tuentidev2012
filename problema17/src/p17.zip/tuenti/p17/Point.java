package tuenti.p17;

public class Point {

	double x, y;

	@Override
	public String toString() {

		return "("+x+","+y+")";
	}
}
